# Shipping the round-3 widgets

## 1. Replace the widget view file

Copy `handoff/index.swift` over `capwords/targets/widget/index.swift`.

It keeps everything structural from your current file — `CapWordsSnapshot`, the
keychain `load()`, `CapWordsProvider`, the midnight refresh policy, the
`capwords://camera` tap target, `.systemSmall` + `.systemMedium` — and replaces
only the views:

- `WidgetState` (`goalHit` / `inProgress` / `atRisk`) derived from
  `wordsToday`, `dailyGoal` and `streak`. It owns the accent colour, the sand
  tone, the sky wash, the pet mood and the mood line, so both sizes stay in step.
- `SmallView` — speech bubble, buddy bottom-right at `pixel: 3.4`, streak chip
  bottom-left, confetti on `goalHit` only.
- `MediumView` — stage: buddy left at `pixel: 5.2`, right column at 176pt with
  badge / big streak / mood line, sun rays on `goalHit` only.

`PixelPet.swift` is unchanged and still supplies `PixelPetStanding`,
`PixelFlame` and `Color(hex:)`. New pixel pieces (`PixelCheck`, `PixelStar`,
`PixelPips`, `StreakChip`, `SunRays`, `Confetti`) live in the new index.swift.

No new colorsets needed — the three accents are hex literals matching
`COLORS` in `src/config.js`:

| role | hex | config key |
|---|---|---|
| done | `#4E7B45` | `leafDark` |
| neutral | `#3A2A1A` | `outline` |
| at risk | `#C1584E` | `danger` |
| streak | `#E0742F` | `streak` |
| sand / dusk sand | `#E8D6AE` / `#E0C9A6` | `panel` |

## 2. Let the snapshot report a sad buddy

`moodForProgress()` in `src/services/widgetService.js` never returns `sad`, so
the at-risk state can never show today. The widget now derives mood itself from
`wordsToday` / `dailyGoal` / `streak`, so nothing is required — but if you want
the app and widget to agree, change that helper to:

```js
function moodForProgress(wordsToday, dailyGoal, streak = 0) {
  if (wordsToday >= dailyGoal) return 'happy';
  if (wordsToday > 0) return 'content';
  if (streak > 0) return 'sad'; // streak on the line
  return 'neutral';
}
```

and pass `streak?.current ?? 0` at the call site.

## 3. Build

```bash
npx expo prebuild -p ios     # only if the target changed
./start.sh
```

Then long-press the home screen → add the CapWords widget. To see each state in
the simulator: hit your daily goal (goalHit), learn 1 word with goal > 1
(inProgress), or clear today's words while `streak > 0` (atRisk).

## 4. Two things to check on device

- The 52pt streak number on the medium is sized for two digits. At three digits
  it will shrink via `.minimumScaleFactor` — not set yet; add
  `.minimumScaleFactor(0.6).lineLimit(1)` if you expect 100-day streaks.
- `SunRays` and `Confetti` are Canvas/Rectangle draws, cheap for WidgetKit, but
  worth an eye on the widget gallery preview where the frame is smaller.
